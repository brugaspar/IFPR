## Orientação a Objetos II - Humberto Beneduzzi

### Aula - 24/11/2020 - 08/02/2021

<div style="border: 2px solid black; height: 50px; padding: 15px">
  <b>Mapeapemento Objeto-Relacional</b>
  <p>Usando banco de dados <b>MySQL</b> e <b>NetBeans</b></p>
</div>